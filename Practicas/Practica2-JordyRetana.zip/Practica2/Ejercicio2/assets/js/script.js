
function cambiarContenido() {
    const parrafo = document.getElementById('parrafo');

    parrafo.innerHTML = "<strong>¡Este texto está en negrita!</strong>";
    
}